import{aV as e,r}from"./D-CtXy3Y.js";const s=e("authStore",()=>({loggedInUser:r(null)}));export{s as u};
