import{_ as r,f as t}from"./D-CtXy3Y.js";const n={};function s(e,c){return t(e.$slots,"default")}const a=r(n,[["render",s]]);export{a as default};
