import"./D-CtXy3Y.js";const t=""+new URL("desta-logo.CC3sxGNG.png",import.meta.url).href;export{t as _};
