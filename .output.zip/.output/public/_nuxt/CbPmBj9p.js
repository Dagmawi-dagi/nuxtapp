import{N as n}from"./D-CtXy3Y.js";function i(r,o){const t=n(r,o);if(!t)throw new TypeError(`[maz-ui](injectStrict) Could not resolve ${r.toString()}`);return t}export{i as n};
