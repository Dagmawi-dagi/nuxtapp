import{c as r,ba as p}from"./D-CtXy3Y.js";function a({componentName:e,providedId:o}){return r(()=>o??`${e}-${p().replace(/:/g,"")}`)}export{a as o};
