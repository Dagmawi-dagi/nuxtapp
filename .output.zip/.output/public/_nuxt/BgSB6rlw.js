import{d as e,e as a}from"./D-CtXy3Y.js";const c={__name:"index",setup(s){return(t,n)=>(a(),e("div",null,"sadasdasd"))}};export{c as default};
